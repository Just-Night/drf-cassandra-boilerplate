#!/bin/bash
set -e

# Ensure Cassandra is ready before executing the scripts
# Очікуємо, поки Cassandra буде готова
while ! nc -z localhost 9042; do
  sleep 1
done

echo "Cassandra started"


# Replace the keyspace placeholder and execute the CQL script
sed -i 's/__KEYSPACE_NAME__/'"$CASSANDRA_KEYSPACE_NAME"'/' .//create_keyspace.cql
cqlsh -f ./create_keyspace.cql

# Run Cassandra in the foreground
exec /opt/bitnami/scripts/cassandra/run.sh
